package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.PreferencesManager
import com.example.data.ai.JarvisAiEngine
import com.example.data.ai.ParsedAction
import com.example.reminder.ReminderManager
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("AETHER", appName)
    }

    @Test
    fun `jarvis ai engine parses alarm action`() = runBlocking {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val prefs = PreferencesManager(context)
        val engine = JarvisAiEngine(prefs)

        val res = engine.processQuery("Set an alarm for 7:30 AM")
        assertTrue(res.action is ParsedAction.SetAlarm)
        val alarm = res.action as ParsedAction.SetAlarm
        assertEquals(7, alarm.hour)
        assertEquals(30, alarm.minute)
        assertTrue(res.replyText.contains("alarm", ignoreCase = true))
    }

    @Test
    fun `reminder manager persists reminder items`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val reminderManager = ReminderManager(context)

        val initialCount = reminderManager.reminders.value.size
        val added = reminderManager.addReminder("Stark Armor Check", System.currentTimeMillis() + 600000L, false)

        assertNotNull(added)
        assertEquals(initialCount + 1, reminderManager.reminders.value.size)
        assertTrue(reminderManager.reminders.value.any { it.title == "Stark Armor Check" })
    }
}
