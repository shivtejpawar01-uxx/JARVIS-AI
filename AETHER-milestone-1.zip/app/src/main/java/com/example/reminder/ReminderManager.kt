package com.example.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.provider.AlarmClock
import android.util.Log
import com.example.model.ReminderItem
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Calendar

class ReminderManager(private val context: Context) {

    private val alarmManager = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
    private val prefs = context.getSharedPreferences("jarvis_reminders_store", Context.MODE_PRIVATE)

    private val _reminders = MutableStateFlow<List<ReminderItem>>(loadReminders())
    val reminders: StateFlow<List<ReminderItem>> = _reminders.asStateFlow()

    private fun loadReminders(): List<ReminderItem> {
        val raw = prefs.getString("reminders_json", null) ?: return defaultReminders()
        val list = mutableListOf<ReminderItem>()
        try {
            val arr = JSONArray(raw)
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                list.add(
                    ReminderItem(
                        id = obj.getString("id"),
                        title = obj.getString("title"),
                        timeMillis = obj.getLong("timeMillis"),
                        isAlarm = obj.optBoolean("isAlarm", false),
                        isEnabled = obj.optBoolean("isEnabled", true),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis())
                    )
                )
            }
        } catch (e: Exception) {
            Log.e("ReminderManager", "Failed to parse reminders", e)
        }
        return if (list.isEmpty()) defaultReminders() else list
    }

    private fun defaultReminders(): List<ReminderItem> {
        val cal = Calendar.getInstance().apply {
            add(Calendar.HOUR_OF_DAY, 2)
        }
        return listOf(
            ReminderItem(
                title = "Arc Reactor Diagnostic Sweep",
                timeMillis = cal.timeInMillis,
                isAlarm = false,
                isEnabled = true
            )
        )
    }

    private fun saveReminders(items: List<ReminderItem>) {
        val arr = JSONArray()
        for (item in items) {
            val obj = JSONObject().apply {
                put("id", item.id)
                put("title", item.title)
                put("timeMillis", item.timeMillis)
                put("isAlarm", item.isAlarm)
                put("isEnabled", item.isEnabled)
                put("createdAt", item.createdAt)
            }
            arr.put(obj)
        }
        prefs.edit().putString("reminders_json", arr.toString()).apply()
        _reminders.value = items
    }

    fun addReminder(title: String, timeMillis: Long, isAlarm: Boolean): ReminderItem {
        val item = ReminderItem(
            title = title,
            timeMillis = timeMillis,
            isAlarm = isAlarm,
            isEnabled = true
        )
        val updated = _reminders.value + item
        saveReminders(updated)
        scheduleSystemAlarm(item)
        return item
    }

    fun toggleReminder(id: String) {
        val updated = _reminders.value.map {
            if (it.id == id) {
                val newEnabled = !it.isEnabled
                val newItem = it.copy(isEnabled = newEnabled)
                if (newEnabled) {
                    scheduleSystemAlarm(newItem)
                } else {
                    cancelSystemAlarm(it)
                }
                newItem
            } else it
        }
        saveReminders(updated)
    }

    fun deleteReminder(id: String) {
        val target = _reminders.value.find { it.id == id }
        if (target != null) {
            cancelSystemAlarm(target)
        }
        val updated = _reminders.value.filterNot { it.id == id }
        saveReminders(updated)
    }

    fun setSystemClockAlarm(hour: Int, minute: Int, message: String): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_ALARM).apply {
                putExtra(AlarmClock.EXTRA_HOUR, hour)
                putExtra(AlarmClock.EXTRA_MINUTES, minute)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e("ReminderManager", "Failed to trigger system clock alarm", e)
            false
        }
    }

    fun setSystemClockTimer(seconds: Int, message: String): Boolean {
        return try {
            val intent = Intent(AlarmClock.ACTION_SET_TIMER).apply {
                putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                putExtra(AlarmClock.EXTRA_MESSAGE, message)
                putExtra(AlarmClock.EXTRA_SKIP_UI, false)
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            context.startActivity(intent)
            true
        } catch (e: Exception) {
            Log.e("ReminderManager", "Failed to trigger system clock timer", e)
            false
        }
    }

    private fun scheduleSystemAlarm(item: ReminderItem) {
        if (!item.isEnabled) return
        if (item.timeMillis <= System.currentTimeMillis()) return

        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.example.jarvis.ALARM_TRIGGER"
            putExtra(AlarmReceiver.EXTRA_TITLE, item.title)
            putExtra(AlarmReceiver.EXTRA_IS_ALARM, item.isAlarm)
            putExtra(AlarmReceiver.EXTRA_ID, item.id.hashCode())
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            item.id.hashCode(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                if (alarmManager.canScheduleExactAlarms()) {
                    alarmManager.setExactAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        item.timeMillis,
                        pendingIntent
                    )
                } else {
                    alarmManager.setAndAllowWhileIdle(
                        AlarmManager.RTC_WAKEUP,
                        item.timeMillis,
                        pendingIntent
                    )
                }
            } else {
                alarmManager.setExactAndAllowWhileIdle(
                    AlarmManager.RTC_WAKEUP,
                    item.timeMillis,
                    pendingIntent
                )
            }
        } catch (e: Exception) {
            Log.e("ReminderManager", "Failed to schedule exact alarm", e)
            try {
                alarmManager.set(
                    AlarmManager.RTC_WAKEUP,
                    item.timeMillis,
                    pendingIntent
                )
            } catch (err: Exception) {
                Log.e("ReminderManager", "Fallback alarm scheduling also failed", err)
            }
        }
    }

    private fun cancelSystemAlarm(item: ReminderItem) {
        val intent = Intent(context, AlarmReceiver::class.java).apply {
            action = "com.example.jarvis.ALARM_TRIGGER"
        }
        val pendingIntent = PendingIntent.getBroadcast(
            context,
            item.id.hashCode(),
            intent,
            PendingIntent.FLAG_NO_CREATE or PendingIntent.FLAG_IMMUTABLE
        )
        if (pendingIntent != null) {
            alarmManager.cancel(pendingIntent)
            pendingIntent.cancel()
        }
    }
}
