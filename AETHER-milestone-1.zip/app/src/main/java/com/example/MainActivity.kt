package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.Crossfade
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.ui.components.HudBottomBar
import com.example.ui.components.HudTelemetryHeader
import com.example.ui.screens.AlarmsRemindersScreen
import com.example.ui.screens.ChatScreen
import com.example.ui.screens.HudCoreScreen
import com.example.ui.screens.SettingsScreen
import com.example.ui.theme.HudBackground
import com.example.ui.theme.JarvisTheme
import com.example.viewmodel.JarvisTab
import com.example.viewmodel.JarvisViewModel

class MainActivity : ComponentActivity() {

    private val viewModel: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()

        setContent {
            JarvisTheme {
                JarvisApp(viewModel = viewModel)
            }
        }
    }

    override fun onPause() {
        super.onPause()
        viewModel.cancelVoiceListening()
    }
}

@Composable
fun JarvisApp(viewModel: JarvisViewModel) {
    val currentTab by viewModel.currentTab.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val statusBanner by viewModel.statusBanner.collectAsState()

    // Handle Back Press: return to AI Core screen if in secondary tab
    BackHandler(enabled = currentTab != JarvisTab.HUD_CORE) {
        viewModel.selectTab(JarvisTab.HUD_CORE)
    }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .background(HudBackground),
        topBar = {
            HudTelemetryHeader(
                statusTicker = statusBanner,
                isSpeaking = isSpeaking,
                onStopSpeaking = { viewModel.stopSpeaking() },
                modifier = Modifier.statusBarsPadding()
            )
        },
        bottomBar = {
            HudBottomBar(
                currentTab = currentTab,
                onTabSelected = { viewModel.selectTab(it) }
            )
        },
        containerColor = HudBackground
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(HudBackground)
        ) {
            Crossfade(
                targetState = currentTab,
                label = "tab_transition"
            ) { tab ->
                when (tab) {
                    JarvisTab.HUD_CORE -> HudCoreScreen(viewModel = viewModel)
                    JarvisTab.COMMS_CHAT -> ChatScreen(viewModel = viewModel)
                    JarvisTab.PROTOCOLS -> AlarmsRemindersScreen(viewModel = viewModel)
                    JarvisTab.SETTINGS -> SettingsScreen(viewModel = viewModel)
                }
            }
        }
    }
}
