package com.example.model

enum class MessageSender {
    USER,
    AETHER,
    SYSTEM
}

data class ChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: MessageSender,
    val text: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isVoiceInput: Boolean = false,
    val actionTag: String? = null,
    val actionDetail: String? = null
)
