package com.example.model

enum class AiCoreState(val label: String) {
    STANDBY("SYSTEM ONLINE"),
    LISTENING("RECEIVING AUDIO..."),
    THINKING("PROCESSING QUERY..."),
    SPEAKING("TRANSMITTING..."),
    ERROR("COMM ERROR")
}
