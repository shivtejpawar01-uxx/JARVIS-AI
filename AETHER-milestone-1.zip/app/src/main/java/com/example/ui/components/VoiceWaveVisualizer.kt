package com.example.ui.components

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.model.AiCoreState
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ArcBlueSecondary
import com.example.ui.theme.ArcCyanGlow
import com.example.ui.theme.ArcCyanPrimary
import com.example.ui.theme.StarkGold
import kotlin.math.sin

@Composable
fun VoiceWaveVisualizer(
    rmsLevel: Float,
    state: AiCoreState,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "wave_phase")
    val wavePhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 6.28318f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1200, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    val baseColor = when (state) {
        AiCoreState.LISTENING -> ArcCyanGlow
        AiCoreState.THINKING -> StarkGold
        AiCoreState.SPEAKING -> ArcCyanPrimary
        AiCoreState.ERROR -> AlertRed
        AiCoreState.STANDBY -> ArcBlueSecondary
    }

    val glowBrush = Brush.verticalGradient(
        colors = listOf(
            baseColor.copy(alpha = 0.95f),
            baseColor.copy(alpha = 0.4f),
            baseColor.copy(alpha = 0.1f)
        )
    )

    Canvas(
        modifier = modifier
            .fillMaxWidth()
            .height(54.dp)
            .testTag("voice_wave_visualizer")
    ) {
        val barCount = 28
        val spacing = size.width / (barCount * 1.6f)
        val barWidth = spacing * 0.65f
        val totalWidth = barCount * spacing
        val startX = (size.width - totalWidth) / 2f
        val centerY = size.height / 2f
        val maxHalfHeight = (size.height * 0.44f)

        for (i in 0 until barCount) {
            val normalizedIdx = (i - (barCount / 2f)) / (barCount / 2f)
            val bellCurve = 1f - (normalizedIdx * normalizedIdx).coerceIn(0f, 0.85f)

            val waveSine = sin((wavePhase + (i * 0.35f)).toDouble()).toFloat()

            val activityMultiplier = when (state) {
                AiCoreState.LISTENING -> (0.25f + rmsLevel * 1.5f).coerceIn(0.15f, 1.2f)
                AiCoreState.SPEAKING -> (0.35f + rmsLevel * 1.3f).coerceIn(0.2f, 1.1f)
                AiCoreState.THINKING -> (0.2f + kotlin.math.abs(waveSine) * 0.4f)
                AiCoreState.STANDBY -> (0.08f + kotlin.math.abs(waveSine) * 0.08f)
                AiCoreState.ERROR -> 0.12f
            }

            val barHeight = (maxHalfHeight * bellCurve * activityMultiplier * (0.8f + kotlin.math.abs(waveSine) * 0.4f))
                .coerceAtLeast(3f)

            val x = startX + (i * spacing)
            val y = centerY - barHeight

            drawRoundRect(
                brush = glowBrush,
                topLeft = Offset(x, y),
                size = Size(barWidth, barHeight * 2),
                cornerRadius = CornerRadius(barWidth / 2f, barWidth / 2f)
            )
        }
    }
}
