package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// AETHER Core Colors
val ArcCyanPrimary = Color(0xFF00E5FF)
val ArcCyanGlow = Color(0xFF84FFFF)
val ArcBlueSecondary = Color(0xFF00B0FF)
val ArcBlueDark = Color(0xFF0288D1)
val ArcNavyDeep = Color(0xFF051329)

// Iron Man Mark Suit Accents
val StarkGold = Color(0xFFFFC107)
val StarkGoldGlow = Color(0xFFFFE082)
val TelemetryGreen = Color(0xFF00E676)
val AlertRed = Color(0xFFFF5252)

// HUD Dark Surfaces
val HudBackground = Color(0xFF04070F)
val HudSurface = Color(0xFF08101E)
val HudSurfaceVariant = Color(0xFF0E1A2E)
val HudCardBorder = Color(0xFF1B3354)
val HudCardBorderGlow = Color(0x6600E5FF)

val TextPrimary = Color(0xFFF0F6FC)
val TextSecondary = Color(0xFF8B9CB5)
val TextTertiary = Color(0xFF566B87)
val TextCyan = Color(0xFF80D8FF)
