package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArcBlueSecondary
import com.example.ui.theme.ArcCyanPrimary
import com.example.ui.theme.HudBackground
import com.example.ui.theme.HudCardBorder
import com.example.ui.theme.HudSurface
import com.example.ui.theme.HudSurfaceVariant
import com.example.ui.theme.StarkGold
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.JarvisViewModel

@Composable
fun SettingsScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val preferences by viewModel.preferences.collectAsState()
    val scrollState = rememberScrollState()

    var keyInput by remember(preferences.customApiKey) {
        mutableStateOf(preferences.customApiKey)
    }
    var keyVisible by remember { mutableStateOf(false) }
    var saveStatusMsg by remember { mutableStateOf<String?>(null) }

    val effectiveKey = viewModel.preferencesManager.getEffectiveApiKey()
    val keyStatus = when {
        preferences.customApiKey.isNotEmpty() -> "CUSTOM KEY CONFIGURED"
        effectiveKey.isNotEmpty() -> "BUILDCONFIG SECRETS ACTIVE"
        else -> "AETHER LOCAL ENGINE (OFFLINE)"
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(HudBackground)
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Section: Title
        Text(
            text = "SYSTEM CONFIGURATION // SETTINGS",
            color = ArcCyanPrimary,
            fontSize = 16.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            letterSpacing = 1.sp
        )

        // Card 1: Gemini API Key & Neural Matrix
        SettingsCard(
            title = "GEMINI AI NEURAL MATRIX",
            icon = Icons.Default.Key,
            iconTint = ArcCyanPrimary
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                // Key Status Pill
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(4.dp))
                        .background(if (effectiveKey.isNotEmpty()) Color(0xFF07261C) else Color(0xFF1D283A))
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = if (effectiveKey.isNotEmpty()) Icons.Default.CheckCircle else Icons.Default.Info,
                        contentDescription = "Key Status",
                        tint = if (effectiveKey.isNotEmpty()) TelemetryGreen else ArcBlueSecondary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = keyStatus,
                        color = if (effectiveKey.isNotEmpty()) TelemetryGreen else TextSecondary,
                        fontSize = 10.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold
                    )
                }

                Text(
                    text = "Configure your personal Gemini API key or use the built-in Secrets. When offline, AETHER operates via local protocols.",
                    color = TextSecondary,
                    fontSize = 12.sp
                )

                OutlinedTextField(
                    value = keyInput,
                    onValueChange = {
                        keyInput = it
                        saveStatusMsg = null
                    },
                    label = { Text("Gemini API Key") },
                    placeholder = { Text("AIzaSy...") },
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("api_key_input"),
                    visualTransformation = if (keyVisible) VisualTransformation.None else PasswordVisualTransformation(),
                    trailingIcon = {
                        IconButton(onClick = { keyVisible = !keyVisible }) {
                            Icon(
                                imageVector = if (keyVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                contentDescription = "Toggle visibility",
                                tint = TextSecondary
                            )
                        }
                    },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = ArcCyanPrimary,
                        unfocusedBorderColor = HudCardBorder,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password)
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    Button(
                        onClick = {
                            viewModel.preferencesManager.setCustomApiKey(keyInput)
                            saveStatusMsg = "API Key saved successfully, sir."
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ArcCyanPrimary),
                        modifier = Modifier.testTag("save_api_key_button")
                    ) {
                        Text(
                            text = "Save Key",
                            color = Color(0xFF001F29),
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                if (saveStatusMsg != null) {
                    Text(
                        text = saveStatusMsg ?: "",
                        color = TelemetryGreen,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        // Card 2: Voice & Spoken Responses Engine
        SettingsCard(
            title = "VOICE & SPEECH SYNTHESIS",
            icon = Icons.Default.VolumeUp,
            iconTint = StarkGold
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                // Auto-speak Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Spoken Responses",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "AETHER speaks replies aloud automatically",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = preferences.autoSpeak,
                        onCheckedChange = { viewModel.preferencesManager.setAutoSpeak(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF001F29),
                            checkedTrackColor = ArcCyanPrimary
                        ),
                        modifier = Modifier.testTag("toggle_auto_speak")
                    )
                }

                // Pitch Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Voice Pitch (British Cadence)",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = String.format("%.2f", preferences.ttsPitch),
                            color = ArcCyanPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Slider(
                        value = preferences.ttsPitch,
                        onValueChange = { viewModel.preferencesManager.setTtsPitch(it) },
                        valueRange = 0.6f..1.4f,
                        colors = SliderDefaults.colors(
                            thumbColor = ArcCyanPrimary,
                            activeTrackColor = ArcCyanPrimary,
                            inactiveTrackColor = HudCardBorder
                        )
                    )
                }

                // Speech Rate Slider
                Column {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = "Speech Rate (Velocity)",
                            color = TextPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                        Text(
                            text = String.format("%.2f", preferences.ttsRate),
                            color = ArcCyanPrimary,
                            fontSize = 12.sp,
                            fontFamily = FontFamily.Monospace
                        )
                    }
                    Slider(
                        value = preferences.ttsRate,
                        onValueChange = { viewModel.preferencesManager.setTtsRate(it) },
                        valueRange = 0.7f..1.5f,
                        colors = SliderDefaults.colors(
                            thumbColor = ArcCyanPrimary,
                            activeTrackColor = ArcCyanPrimary,
                            inactiveTrackColor = HudCardBorder
                        )
                    )
                }

                // Voice Test Button
                Button(
                    onClick = {
                        viewModel.replayMessageVoice(
                            "Testing audio synthesis, All neural phonetic matrices are functioning at maximum clarity."
                        )
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF132845)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(
                        imageVector = Icons.Default.VolumeUp,
                        contentDescription = "Test Voice",
                        tint = ArcCyanPrimary,
                        modifier = Modifier.size(16.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "TEST AETHER VOICE",
                        color = ArcCyanPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Card 3: Optimization & Low-RAM Mode
        SettingsCard(
            title = "PERFORMANCE & LOW-RAM OPTIMIZATION",
            icon = Icons.Default.Speed,
            iconTint = TelemetryGreen
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Low-RAM / Energy Conservation",
                            color = TextPrimary,
                            fontSize = 14.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                        Text(
                            text = "Lightweight canvas rendering optimized for Android 11 & low-memory devices",
                            color = TextSecondary,
                            fontSize = 11.sp
                        )
                    }

                    Switch(
                        checked = preferences.lowRamMode,
                        onCheckedChange = { viewModel.preferencesManager.setLowRamMode(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color(0xFF001F29),
                            checkedTrackColor = TelemetryGreen
                        ),
                        modifier = Modifier.testTag("toggle_low_ram")
                    )
                }
            }
        }

        // Card 4: Stark Diagnostics & System Specs
        SettingsCard(
            title = "STARK INDUSTRIES DIAGNOSTICS",
            icon = Icons.Default.Memory,
            iconTint = ArcBlueSecondary
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                DiagnosticsRow(label = "ASSISTANT PROTOCOL", value = "AETHER")
                DiagnosticsRow(label = "TARGET ANDROID SDK", value = "API 36 (Android 11+ Ready)")
                DiagnosticsRow(label = "SPEECH ENGINE", value = "Native Android STT & TTS")
                DiagnosticsRow(label = "PERSISTENCE", value = "AlarmManager & Local SharedPreferences")

                Spacer(modifier = Modifier.height(4.dp))

                Button(
                    onClick = { viewModel.runDiagnostics() },
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF0B213A)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "RUN COMPLETE DIAGNOSTIC SWEEP",
                        color = ArcCyanPrimary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))
    }
}

@Composable
private fun SettingsCard(
    title: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    content: @Composable () -> Unit
) {
    Box(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(8.dp))
            .background(HudSurface)
            .border(1.dp, HudCardBorder, RoundedCornerShape(8.dp))
            .padding(14.dp)
    ) {
        Column {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(bottom = 10.dp)
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(18.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = title,
                    color = iconTint,
                    fontSize = 12.sp,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    letterSpacing = 1.sp
                )
            }
            content()
        }
    }
}

@Composable
private fun DiagnosticsRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween
    ) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace
        )
        Text(
            text = value,
            color = TextPrimary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium
        )
    }
}
