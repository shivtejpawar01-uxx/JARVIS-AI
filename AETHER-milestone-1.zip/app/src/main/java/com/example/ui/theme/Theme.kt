package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val JarvisColorScheme = darkColorScheme(
    primary = ArcCyanPrimary,
    onPrimary = Color(0xFF001F29),
    primaryContainer = Color(0xFF004D61),
    onPrimaryContainer = Color(0xFFBCE9FF),

    secondary = ArcBlueSecondary,
    onSecondary = Color(0xFF002F6C),
    secondaryContainer = Color(0xFF0D325E),
    onSecondaryContainer = Color(0xFFD1E4FF),

    tertiary = StarkGold,
    onTertiary = Color(0xFF261A00),
    tertiaryContainer = Color(0xFF4A3400),
    onTertiaryContainer = Color(0xFFFFDEA3),

    background = HudBackground,
    onBackground = TextPrimary,

    surface = HudSurface,
    onSurface = TextPrimary,
    surfaceVariant = HudSurfaceVariant,
    onSurfaceVariant = TextSecondary,

    outline = HudCardBorder,
    outlineVariant = Color(0xFF14243B)
)

@Composable
fun JarvisTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = JarvisColorScheme,
        typography = Typography,
        content = content
    )
}
