package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Alarm
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Memory
import androidx.compose.material.icons.filled.RadioButtonChecked
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.ArcBlueSecondary
import com.example.ui.theme.ArcCyanPrimary
import com.example.ui.theme.HudCardBorder
import com.example.ui.theme.HudSurface
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.JarvisTab

@Composable
fun HudBottomBar(
    currentTab: JarvisTab,
    onTabSelected: (JarvisTab) -> Unit,
    modifier: Modifier = Modifier
) {
    Row(
        modifier = modifier
            .fillMaxWidth()
            .background(HudSurface)
            .border(width = 1.dp, color = HudCardBorder)
            .navigationBarsPadding()
            .padding(horizontal = 8.dp, vertical = 6.dp)
            .testTag("hud_bottom_bar"),
        horizontalArrangement = Arrangement.SpaceAround,
        verticalAlignment = Alignment.CenterVertically
    ) {
        HudTabItem(
            tab = JarvisTab.HUD_CORE,
            label = "AI CORE",
            icon = Icons.Default.RadioButtonChecked,
            isSelected = currentTab == JarvisTab.HUD_CORE,
            onClick = { onTabSelected(JarvisTab.HUD_CORE) }
        )
        HudTabItem(
            tab = JarvisTab.COMMS_CHAT,
            label = "COMMS",
            icon = Icons.Default.Chat,
            isSelected = currentTab == JarvisTab.COMMS_CHAT,
            onClick = { onTabSelected(JarvisTab.COMMS_CHAT) }
        )
        HudTabItem(
            tab = JarvisTab.PROTOCOLS,
            label = "ALARMS",
            icon = Icons.Default.Alarm,
            isSelected = currentTab == JarvisTab.PROTOCOLS,
            onClick = { onTabSelected(JarvisTab.PROTOCOLS) }
        )
        HudTabItem(
            tab = JarvisTab.SETTINGS,
            label = "SYSTEM",
            icon = Icons.Default.Memory,
            isSelected = currentTab == JarvisTab.SETTINGS,
            onClick = { onTabSelected(JarvisTab.SETTINGS) }
        )
    }
}

@Composable
private fun HudTabItem(
    tab: JarvisTab,
    label: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    val activeColor = ArcCyanPrimary
    val inactiveColor = TextSecondary

    Column(
        modifier = Modifier
            .clip(RoundedCornerShape(6.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 6.dp)
            .testTag("tab_${tab.name.lowercase()}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Icon(
            imageVector = icon,
            contentDescription = label,
            tint = if (isSelected) activeColor else inactiveColor,
            modifier = Modifier.size(22.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            color = if (isSelected) activeColor else inactiveColor,
            fontSize = 10.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            letterSpacing = 0.5.sp
        )
        // Glowing bar underneath if selected
        if (isSelected) {
            Spacer(modifier = Modifier.height(2.dp))
            Box(
                modifier = Modifier
                    .size(width = 24.dp, height = 2.dp)
                    .background(activeColor)
            )
        } else {
            Spacer(modifier = Modifier.height(4.dp))
        }
    }
}
