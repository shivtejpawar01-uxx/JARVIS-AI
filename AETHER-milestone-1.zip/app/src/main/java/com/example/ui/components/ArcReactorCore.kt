package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.AiCoreState
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ArcBlueDark
import com.example.ui.theme.ArcBlueSecondary
import com.example.ui.theme.ArcCyanGlow
import com.example.ui.theme.ArcCyanPrimary
import com.example.ui.theme.ArcNavyDeep
import com.example.ui.theme.StarkGold
import com.example.ui.theme.StarkGoldGlow
import com.example.ui.theme.TextSecondary
import kotlin.math.cos
import kotlin.math.sin

@Composable
fun ArcReactorCore(
    state: AiCoreState,
    rmsLevel: Float,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    val infiniteTransition = rememberInfiniteTransition(label = "arc_reactor")

    // Rotation speeds adapt to state (faster when THINKING, rhythmic when SPEAKING)
    val outerDuration = when (state) {
        AiCoreState.THINKING -> 3500
        AiCoreState.LISTENING -> 6000
        AiCoreState.SPEAKING -> 8000
        else -> 18000
    }

    val innerDuration = when (state) {
        AiCoreState.THINKING -> 2200
        AiCoreState.LISTENING -> 4500
        AiCoreState.SPEAKING -> 5000
        else -> 12000
    }

    val outerRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = outerDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "outer_rot"
    )

    val innerRotation by infiniteTransition.animateFloat(
        initialValue = 360f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = innerDuration, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "inner_rot"
    )

    // Breathing pulse for core glow
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 0.85f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(
                durationMillis = if (state == AiCoreState.LISTENING) 700 else 1800,
                easing = FastOutSlowInEasing
            ),
            repeatMode = RepeatMode.Reverse
        ),
        label = "core_pulse"
    )

    // Colors determined by state
    val (primaryGlow, secondaryGlow) = when (state) {
        AiCoreState.LISTENING -> Pair(ArcCyanGlow, ArcCyanPrimary)
        AiCoreState.THINKING -> Pair(StarkGoldGlow, StarkGold)
        AiCoreState.SPEAKING -> Pair(ArcCyanPrimary, ArcBlueSecondary)
        AiCoreState.ERROR -> Pair(AlertRed, Color(0xFFB71C1C))
        AiCoreState.STANDBY -> Pair(ArcCyanPrimary, ArcBlueSecondary)
    }

    Column(
        modifier = modifier,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Box(
            modifier = Modifier
                .size(230.dp)
                .clickable(
                    interactionSource = remember { MutableInteractionSource() },
                    indication = null,
                    onClick = onClick
                )
                .testTag("arc_reactor_core"),
            contentAlignment = Alignment.Center
        ) {
            Canvas(modifier = Modifier.size(230.dp)) {
                val center = Offset(size.width / 2f, size.height / 2f)
                val baseRadius = size.minDimension / 2f

                // Audio reactive expansion
                val audioExpansion = (rmsLevel * 18f).coerceIn(0f, 24f)
                val dynamicRadius = baseRadius - 10f + audioExpansion

                // 1. Outer Deep Aura Ring
                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            primaryGlow.copy(alpha = 0.25f + rmsLevel * 0.35f),
                            secondaryGlow.copy(alpha = 0.08f),
                            Color.Transparent
                        ),
                        center = center,
                        radius = dynamicRadius * 1.15f
                    ),
                    center = center,
                    radius = dynamicRadius * 1.15f
                )

                // 2. Outer segmented HUD Ring (Rotating clockwise)
                rotate(outerRotation, pivot = center) {
                    drawArcReactorOuterRing(center, dynamicRadius * 0.94f, primaryGlow)
                }

                // 3. Middle Dash Track Ring (Rotating counter-clockwise)
                rotate(innerRotation, pivot = center) {
                    drawMiddleDashedRing(center, dynamicRadius * 0.78f, secondaryGlow)
                }

                // 4. Ten Arc Reactor Segment Nodes
                rotate(outerRotation * 0.5f, pivot = center) {
                    drawReactorTriangles(center, dynamicRadius * 0.62f, primaryGlow)
                }

                // 5. Inner Core Chamber
                val coreRadius = (dynamicRadius * 0.40f * pulseScale).coerceAtLeast(10f)
                drawCircle(
                    color = ArcNavyDeep,
                    center = center,
                    radius = coreRadius + 4f
                )

                drawCircle(
                    brush = Brush.radialGradient(
                        colors = listOf(
                            Color.White,
                            primaryGlow,
                            secondaryGlow,
                            ArcBlueDark
                        ),
                        center = center,
                        radius = coreRadius
                    ),
                    center = center,
                    radius = coreRadius
                )

                // 6. Center Energy Node
                drawCircle(
                    color = Color.White,
                    center = center,
                    radius = coreRadius * 0.28f
                )

                // 7. Tactical Crosshairs
                drawCrosshairs(center, dynamicRadius * 0.98f, primaryGlow.copy(alpha = 0.6f))
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // State & Subsystem readout
        Text(
            text = state.label,
            color = primaryGlow,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp,
            letterSpacing = 2.sp
        )

        Text(
            text = if (state == AiCoreState.LISTENING) "TAP TO FINISH VOICE INPUT" else "TAP REACTOR FOR VOICE PROTOCOL",
            color = TextSecondary,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            letterSpacing = 1.sp
        )
    }
}

private fun DrawScope.drawArcReactorOuterRing(center: Offset, radius: Float, glowColor: Color) {
    // Thin outer boundary
    drawCircle(
        color = glowColor.copy(alpha = 0.35f),
        center = center,
        radius = radius,
        style = Stroke(width = 1.5f)
    )

    // Segmented chunks (4 main arcs)
    for (i in 0 until 4) {
        val startAngle = i * 90f + 12f
        val sweepAngle = 66f
        drawArc(
            color = glowColor,
            startAngle = startAngle,
            sweepAngle = sweepAngle,
            useCenter = false,
            topLeft = Offset(center.x - radius, center.y - radius),
            size = androidx.compose.ui.geometry.Size(radius * 2, radius * 2),
            style = Stroke(width = 3.5f, cap = StrokeCap.Round)
        )
    }
}

private fun DrawScope.drawMiddleDashedRing(center: Offset, radius: Float, color: Color) {
    drawCircle(
        color = color.copy(alpha = 0.8f),
        center = center,
        radius = radius,
        style = Stroke(
            width = 3f,
            pathEffect = PathEffect.dashPathEffect(floatArrayOf(14f, 10f), 0f)
        )
    )
}

private fun DrawScope.drawReactorTriangles(center: Offset, radius: Float, color: Color) {
    val count = 10
    val angleStep = (2 * Math.PI / count).toFloat()

    for (i in 0 until count) {
        val angle = i * angleStep
        val x = center.x + radius * cos(angle.toDouble()).toFloat()
        val y = center.y + radius * sin(angle.toDouble()).toFloat()

        // Small glowing power block
        drawCircle(
            color = color,
            center = Offset(x, y),
            radius = 3.5f
        )
    }
}

private fun DrawScope.drawCrosshairs(center: Offset, radius: Float, color: Color) {
    val markLength = 12f
    // Top
    drawLine(color, Offset(center.x, center.y - radius), Offset(center.x, center.y - radius + markLength), strokeWidth = 2f)
    // Bottom
    drawLine(color, Offset(center.x, center.y + radius), Offset(center.x, center.y + radius - markLength), strokeWidth = 2f)
    // Left
    drawLine(color, Offset(center.x - radius, center.y), Offset(center.x - radius + markLength, center.y), strokeWidth = 2f)
    // Right
    drawLine(color, Offset(center.x + radius, center.y), Offset(center.x + radius - markLength, center.y), strokeWidth = 2f)
}
