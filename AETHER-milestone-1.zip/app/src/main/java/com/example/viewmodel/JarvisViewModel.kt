package com.example.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.JarvisPreferences
import com.example.data.PreferencesManager
import com.example.data.ai.JarvisAiEngine
import com.example.data.ai.ParsedAction
import com.example.model.AiCoreState
import com.example.model.ChatMessage
import com.example.model.MessageSender
import com.example.model.ReminderItem
import com.example.reminder.ReminderManager
import com.example.speech.SpeechRecognizerManager
import com.example.speech.TextToSpeechManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Calendar

enum class JarvisTab(val title: String) {
    HUD_CORE("AI CORE"),
    COMMS_CHAT("COMMS"),
    PROTOCOLS("ALARMS"),
    SETTINGS("SYSTEM")
}

class JarvisViewModel(application: Application) : AndroidViewModel(application) {

    val preferencesManager = PreferencesManager(application)
    val reminderManager = ReminderManager(application)
    private val aiEngine = JarvisAiEngine(preferencesManager)

    private val _currentTab = MutableStateFlow(JarvisTab.HUD_CORE)
    val currentTab: StateFlow<JarvisTab> = _currentTab.asStateFlow()

    private val _aiCoreState = MutableStateFlow(AiCoreState.STANDBY)
    val aiCoreState: StateFlow<AiCoreState> = _aiCoreState.asStateFlow()

    private val _messages = MutableStateFlow<List<ChatMessage>>(initialMessages())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _statusBanner = MutableStateFlow("ALL SYSTEMS FUNCTIONAL // ARC REACTOR NOMINAL")
    val statusBanner: StateFlow<String> = _statusBanner.asStateFlow()

    // Speech Managers
    private val speechRecognizerManager = SpeechRecognizerManager(application) { speechText ->
        handleSpeechResult(speechText)
    }

    private val textToSpeechManager = TextToSpeechManager(application)

    val isListening: StateFlow<Boolean> = speechRecognizerManager.isListening
    val isSpeaking: StateFlow<Boolean> = textToSpeechManager.isSpeaking
    val rmsLevel: StateFlow<Float> = speechRecognizerManager.rmsLevel
    val partialTranscript: StateFlow<String> = speechRecognizerManager.partialText
    val speechError: StateFlow<String?> = speechRecognizerManager.error

    val reminders: StateFlow<List<ReminderItem>> = reminderManager.reminders
    val preferences: StateFlow<JarvisPreferences> = preferencesManager.preferences

    private var speechPulseJob: Job? = null

    init {
        // Monitor TTS speaking state to update AiCoreState
        viewModelScope.launch {
            textToSpeechManager.isSpeaking.collect { speaking ->
                if (speaking) {
                    _aiCoreState.value = AiCoreState.SPEAKING
                    startSimulatedSpeechAudioWaves()
                } else {
                    speechPulseJob?.cancel()
                    if (_aiCoreState.value == AiCoreState.SPEAKING) {
                        _aiCoreState.value = AiCoreState.STANDBY
                    }
                }
            }
        }

        // Monitor speech recognizer state
        viewModelScope.launch {
            speechRecognizerManager.isListening.collect { listening ->
                if (listening) {
                    textToSpeechManager.stop()
                    _aiCoreState.value = AiCoreState.LISTENING
                } else if (_aiCoreState.value == AiCoreState.LISTENING) {
                    _aiCoreState.value = AiCoreState.STANDBY
                }
            }
        }
    }

    private fun initialMessages(): List<ChatMessage> {
        return listOf(
            ChatMessage(
                sender = MessageSender.AETHER,
                text = "AETHER is online. What can I help you with?"
            )
        )
    }

    fun selectTab(tab: JarvisTab) {
        _currentTab.value = tab
    }

    fun toggleVoiceListening() {
        if (speechRecognizerManager.isListening.value) {
            speechRecognizerManager.stopListening()
        } else {
            textToSpeechManager.stop()
            speechRecognizerManager.startListening()
        }
    }

    fun cancelVoiceListening() {
        speechRecognizerManager.stopListening()
    }

    fun stopSpeaking() {
        textToSpeechManager.stop()
        _aiCoreState.value = AiCoreState.STANDBY
    }

    private fun handleSpeechResult(recognizedText: String) {
        if (recognizedText.isBlank()) return
        sendMessage(recognizedText, isVoice = true)
    }

    fun sendMessage(userText: String, isVoice: Boolean = false) {
        val trimmed = userText.trim()
        if (trimmed.isEmpty()) return

        val userMsg = ChatMessage(
            sender = MessageSender.USER,
            text = trimmed,
            isVoiceInput = isVoice
        )
        _messages.value = _messages.value + userMsg

        _aiCoreState.value = AiCoreState.THINKING
        _statusBanner.value = "QUERYING NEURAL MATRIX..."

        viewModelScope.launch {
            val response = aiEngine.processQuery(trimmed)

            // Handle actions like setting alarms/reminders
            when (val act = response.action) {
                is ParsedAction.SetAlarm -> {
                    val cal = Calendar.getInstance().apply {
                        set(Calendar.HOUR_OF_DAY, act.hour)
                        set(Calendar.MINUTE, act.minute)
                        set(Calendar.SECOND, 0)
                        if (timeInMillis <= System.currentTimeMillis()) {
                            add(Calendar.DAY_OF_YEAR, 1)
                        }
                    }
                    reminderManager.addReminder(act.label, cal.timeInMillis, isAlarm = true)
                    _statusBanner.value = "ALARM CONFIGURED // ${String.format("%02d:%02d", act.hour, act.minute)}"
                }
                is ParsedAction.SetReminder -> {
                    val remTime = System.currentTimeMillis() + (act.durationMinutes * 60 * 1000L)
                    reminderManager.addReminder(act.title, remTime, isAlarm = false)
                    _statusBanner.value = "PROTOCOL REMINDER SCHEDULED // ${act.durationMinutes} MINS"
                }
                is ParsedAction.SystemDiagnostics -> {
                    _statusBanner.value = "DIAGNOSTICS COMPLETE // ALL PROTOCOLS NOMINAL"
                }
                ParsedAction.None -> {
                    _statusBanner.value = if (response.isOnlineGemini) "GEMINI NEURAL LINK ACTIVE" else "LOCAL PROTOCOL MATRIX ACTIVE"
                }
            }

            val jarvisMsg = ChatMessage(
                sender = MessageSender.AETHER,
                text = response.replyText,
                actionTag = when (response.action) {
                    is ParsedAction.SetAlarm -> "ALARM_SCHEDULED"
                    is ParsedAction.SetReminder -> "REMINDER_SCHEDULED"
                    is ParsedAction.SystemDiagnostics -> "DIAGNOSTICS_RUN"
                    ParsedAction.None -> null
                }
            )
            _messages.value = _messages.value + jarvisMsg

            // Speak response if autoSpeak is enabled
            val prefs = preferencesManager.preferences.value
            if (prefs.autoSpeak) {
                textToSpeechManager.speak(response.replyText, prefs.ttsPitch, prefs.ttsRate)
            } else {
                _aiCoreState.value = AiCoreState.STANDBY
            }
        }
    }

    fun replayMessageVoice(text: String) {
        val prefs = preferencesManager.preferences.value
        textToSpeechManager.speak(text, prefs.ttsPitch, prefs.ttsRate)
    }

    fun addManualAlarm(hour: Int, minute: Int, title: String, alsoUseSystemClock: Boolean = true) {
        val cal = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, hour)
            set(Calendar.MINUTE, minute)
            set(Calendar.SECOND, 0)
            if (timeInMillis <= System.currentTimeMillis()) {
                add(Calendar.DAY_OF_YEAR, 1)
            }
        }
        val label = if (title.isBlank()) "AETHER Alarm" else title
        reminderManager.addReminder(label, cal.timeInMillis, isAlarm = true)
        if (alsoUseSystemClock) {
            reminderManager.setSystemClockAlarm(hour, minute, label)
        }
        _statusBanner.value = "ALARM CONFIRMED FOR ${String.format("%02d:%02d", hour, minute)}"
        speakFeedback("Alarm initialized for ${String.format("%02d:%02d", hour, minute)}, sir.")
    }

    fun addManualReminder(durationMinutes: Int, title: String) {
        val remTime = System.currentTimeMillis() + (durationMinutes * 60 * 1000L)
        val label = if (title.isBlank()) "Protocol Checkpoint" else title
        reminderManager.addReminder(label, remTime, isAlarm = false)
        _statusBanner.value = "REMINDER SET IN $durationMinutes MINS"
        speakFeedback("Reminder scheduled for '$label' in $durationMinutes minutes, sir.")
    }

    fun toggleReminder(id: String) {
        reminderManager.toggleReminder(id)
    }

    fun deleteReminder(id: String) {
        reminderManager.deleteReminder(id)
    }

    fun clearChat() {
        _messages.value = initialMessages()
        _statusBanner.value = "COMMS LOG CLEARED"
    }

    fun runDiagnostics() {
        sendMessage("Run complete system diagnostics and report Arc Reactor efficiency", isVoice = false)
    }

    private fun speakFeedback(text: String) {
        val prefs = preferencesManager.preferences.value
        if (prefs.autoSpeak) {
            textToSpeechManager.speak(text, prefs.ttsPitch, prefs.ttsRate)
        }
    }

    // Generates simulated pulsing audio levels while TTS speaks to make the Arc Reactor & waveform dance
    private fun startSimulatedSpeechAudioWaves() {
        speechPulseJob?.cancel()
        speechPulseJob = viewModelScope.launch {
            var phase = 0f
            while (textToSpeechManager.isSpeaking.value) {
                phase += 0.25f
                val fakeRms = ((kotlin.math.sin(phase.toDouble()).toFloat() * 0.4f) + 0.5f).coerceIn(0.1f, 0.95f)
                (speechRecognizerManager.rmsLevel as? MutableStateFlow)?.value = fakeRms
                delay(70)
            }
            (speechRecognizerManager.rmsLevel as? MutableStateFlow)?.value = 0f
        }
    }

    override fun onCleared() {
        super.onCleared()
        speechPulseJob?.cancel()
        speechRecognizerManager.stopListening()
        textToSpeechManager.shutdown()
    }
}
