# AETHER build notes — milestone 1

## Updated
- Android app display name is now AETHER.
- Gemini system instruction now defines AETHER as clear, simple, balanced, and slightly playful.
- Replaced the old Iron Man/J.A.R.V.I.S. identity in key assistant responses and visible interface labels.

## Not implemented yet
- The standalone wake phrase `AETHER` is not active.
- Current speech input is tap-to-listen using Android SpeechRecognizer; it is not an always-on hotword detector.
- Reliable background wake-word detection needs an on-device keyword-spotting engine and a microphone foreground service, with user permission and a persistent notification.
- Phone control, notification reading, WhatsApp actions, and call handling are not implemented by this milestone.

## Next
Integrate and test an on-device wake-word engine, then implement its foreground-service lifecycle. Do not present wake-word detection as working until it is tested on the target phone.
