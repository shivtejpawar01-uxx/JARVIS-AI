package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.example.model.AiCoreState
import com.example.model.MessageSender
import com.example.ui.components.ArcReactorCore
import com.example.ui.components.VoiceWaveVisualizer
import com.example.ui.theme.AlertRed
import com.example.ui.theme.ArcBlueSecondary
import com.example.ui.theme.ArcCyanGlow
import com.example.ui.theme.ArcCyanPrimary
import com.example.ui.theme.ArcNavyDeep
import com.example.ui.theme.HudBackground
import com.example.ui.theme.HudCardBorder
import com.example.ui.theme.HudSurfaceVariant
import com.example.ui.theme.StarkGold
import com.example.ui.theme.TelemetryGreen
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.JarvisTab
import com.example.viewmodel.JarvisViewModel

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun HudCoreScreen(
    viewModel: JarvisViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val aiCoreState by viewModel.aiCoreState.collectAsState()
    val isListening by viewModel.isListening.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val rmsLevel by viewModel.rmsLevel.collectAsState()
    val partialTranscript by viewModel.partialTranscript.collectAsState()
    val speechError by viewModel.speechError.collectAsState()
    val messages by viewModel.messages.collectAsState()
    val reminders by viewModel.reminders.collectAsState()

    var showPermissionRationale by remember { mutableStateOf(false) }

    val permissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.toggleVoiceListening()
        } else {
            showPermissionRationale = true
        }
    }

    fun onMicClicked() {
        if (isSpeaking) {
            viewModel.stopSpeaking()
            return
        }

        val hasAudioPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.RECORD_AUDIO
        ) == PackageManager.PERMISSION_GRANTED

        if (hasAudioPerm) {
            viewModel.toggleVoiceListening()
        } else {
            permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }

    val lastJarvisMessage = messages.lastOrNull { it.sender == MessageSender.JARVIS }?.text
        ?: "Awaiting command, sir."

    val scrollState = rememberScrollState()

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(HudBackground)
            .verticalScroll(scrollState)
            .padding(horizontal = 16.dp, vertical = 8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // System Telemetry Metrics bar
        TelemetryMetricRow(activeRemindersCount = reminders.count { it.isEnabled })

        Spacer(modifier = Modifier.height(18.dp))

        // Center Glowing Arc Reactor AI Core
        ArcReactorCore(
            state = aiCoreState,
            rmsLevel = rmsLevel,
            onClick = { onMicClicked() }
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Animated Voice Wave Visualizer
        VoiceWaveVisualizer(
            rmsLevel = rmsLevel,
            state = aiCoreState
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Live Transcript or Response Display Box
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(HudSurfaceVariant)
                .border(1.dp, if (isListening) ArcCyanPrimary else HudCardBorder, RoundedCornerShape(8.dp))
                .padding(14.dp)
                .testTag("transcript_box")
        ) {
            Column {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = if (isListening) "SPEECH STREAMING..." else "J.A.R.V.I.S. VOICE FEED",
                        color = if (isListening) ArcCyanGlow else StarkGold,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        letterSpacing = 1.sp
                    )

                    if (isSpeaking) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.GraphicEq,
                                contentDescription = "Speaking",
                                tint = ArcCyanPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "SPEAKING",
                                color = ArcCyanPrimary,
                                fontSize = 10.sp,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                val displayText = when {
                    isListening && partialTranscript.isNotEmpty() -> "\"$partialTranscript\""
                    isListening -> "Listening for your voice command, sir..."
                    else -> lastJarvisMessage
                }

                Text(
                    text = displayText,
                    color = TextPrimary,
                    fontSize = 14.sp,
                    fontFamily = FontFamily.SansSerif,
                    lineHeight = 20.sp
                )

                if (speechError != null && isListening) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = speechError ?: "",
                        color = AlertRed,
                        fontSize = 11.sp,
                        fontFamily = FontFamily.Monospace
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Primary Action Controls (Mic Button & Status)
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Main Mic Trigger Button
            Button(
                onClick = { onMicClicked() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (isListening) AlertRed else ArcCyanPrimary,
                    contentColor = if (isListening) Color.White else Color(0xFF001F29)
                ),
                shape = RoundedCornerShape(24.dp),
                modifier = Modifier
                    .height(48.dp)
                    .testTag("hud_voice_button")
            ) {
                Icon(
                    imageVector = when {
                        isSpeaking -> Icons.Default.Stop
                        isListening -> Icons.Default.MicOff
                        else -> Icons.Default.Mic
                    },
                    contentDescription = "Voice Input",
                    modifier = Modifier.size(20.dp)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = when {
                        isSpeaking -> "STOP J.A.R.V.I.S."
                        isListening -> "DISENGAGE MIC"
                        else -> "ENGAGE VOICE"
                    },
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
            }
        }

        // Permission rationale message if denied
        AnimatedVisibility(visible = showPermissionRationale) {
            Column(
                modifier = Modifier
                    .padding(top = 10.dp)
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(6.dp))
                    .background(Color(0xFF261014))
                    .border(1.dp, AlertRed.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
                    .padding(10.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Text(
                    text = "Microphone access is required for J.A.R.V.I.S. speech recognition.",
                    color = Color.White,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )
                Spacer(modifier = Modifier.height(6.dp))
                Button(
                    onClick = {
                        permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        showPermissionRationale = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = AlertRed)
                ) {
                    Text("Grant Permission", fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // Quick Tactical Command Chips
        Text(
            text = "QUICK PROTOCOL PROTOCOLS",
            color = TextSecondary,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 1.5.sp,
            modifier = Modifier.align(Alignment.Start)
        )

        Spacer(modifier = Modifier.height(8.dp))

        FlowRow(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            CommandChip(label = "⏰ Set Alarm 7:00 AM") {
                viewModel.sendMessage("Set an alarm for 7:00 AM")
            }
            CommandChip(label = "⏳ Remind in 10m") {
                viewModel.sendMessage("Remind me in 10 minutes to inspect the arc reactor")
            }
            CommandChip(label = "🛡️ System Diagnostics") {
                viewModel.sendMessage("Run complete system diagnostics")
            }
            CommandChip(label = "🌤️ Weather Briefing") {
                viewModel.sendMessage("What is the current atmospheric status and weather?")
            }
            CommandChip(label = "🤖 Who is Iron Man?") {
                viewModel.sendMessage("Who is Tony Stark and what is Iron Man?")
            }
            CommandChip(label = "💬 Open Comms") {
                viewModel.selectTab(JarvisTab.COMMS_CHAT)
            }
        }

        Spacer(modifier = Modifier.height(24.dp))
    }
}

@Composable
private fun TelemetryMetricRow(activeRemindersCount: Int) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(6.dp))
            .background(Color(0xFF060D1A))
            .border(1.dp, HudCardBorder, RoundedCornerShape(6.dp))
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        MetricItem(label = "CORE OUTPUT", value = "100%", color = ArcCyanPrimary)
        MetricItem(label = "TEMP", value = "34°C", color = TelemetryGreen)
        MetricItem(label = "ALARMS", value = "$activeRemindersCount ACTIVE", color = StarkGold)
        MetricItem(label = "NETWORK", value = "ONLINE", color = TelemetryGreen)
    }
}

@Composable
private fun MetricItem(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(
            text = label,
            color = TextSecondary,
            fontSize = 9.sp,
            fontFamily = FontFamily.Monospace,
            letterSpacing = 0.5.sp
        )
        Text(
            text = value,
            color = color,
            fontSize = 11.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun CommandChip(
    label: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(Color(0xFF0C182B))
            .border(1.dp, ArcBlueSecondary.copy(alpha = 0.5f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("command_chip_${label.filter { it.isLetter() }.take(10)}")
    ) {
        Text(
            text = label,
            color = ArcCyanPrimary,
            fontSize = 12.sp,
            fontFamily = FontFamily.Monospace,
            fontWeight = FontWeight.Medium
        )
    }
}
