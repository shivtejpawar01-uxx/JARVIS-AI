package com.example.data.ai

import android.util.Log
import com.example.data.PreferencesManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit
import java.util.regex.Pattern

sealed class ParsedAction {
    data class SetAlarm(val hour: Int, val minute: Int, val label: String) : ParsedAction()
    data class SetReminder(val durationMinutes: Int, val title: String) : ParsedAction()
    object SystemDiagnostics : ParsedAction()
    object None : ParsedAction()
}

data class JarvisResponse(
    val replyText: String,
    val action: ParsedAction = ParsedAction.None,
    val isOnlineGemini: Boolean = false
)

class JarvisAiEngine(
    private val preferencesManager: PreferencesManager
) {
    private val client = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(20, TimeUnit.SECONDS)
        .build()

    private val jsonMediaType = "application/json; charset=utf-8".toMediaType()

    suspend fun processQuery(userInput: String): JarvisResponse = withContext(Dispatchers.IO) {
        val trimmed = userInput.trim()
        val parsedAction = detectAction(trimmed)

        val apiKey = preferencesManager.getEffectiveApiKey()
        if (apiKey.isNotEmpty()) {
            try {
                val geminiReply = callGeminiApi(apiKey, trimmed)
                if (geminiReply.isNotBlank()) {
                    return@withContext JarvisResponse(
                        replyText = geminiReply,
                        action = parsedAction,
                        isOnlineGemini = true
                    )
                }
            } catch (e: Exception) {
                Log.w("JarvisAiEngine", "Gemini API error, falling back to local protocol: ${e.message}")
            }
        }

        // Offline / Fallback Local Protocol Engine
        val localReply = generateLocalProtocolReply(trimmed, parsedAction)
        JarvisResponse(
            replyText = localReply,
            action = parsedAction,
            isOnlineGemini = false
        )
    }

    private fun detectAction(input: String): ParsedAction {
        val lower = input.lowercase(Locale.ROOT)

        // 1. Check for Alarm: "set alarm for 7:30 am", "alarm at 8", "wake me up at 6:45"
        val alarmPattern = Pattern.compile("(?:set (?:an )?alarm (?:for|at)|wake me up at|alarm at)\\s+(\\d{1,2})(?::(\\d{2}))?\\s*(am|pm)?", Pattern.CASE_INSENSITIVE)
        val alarmMatcher = alarmPattern.matcher(lower)
        if (alarmMatcher.find()) {
            var hour = alarmMatcher.group(1)?.toIntOrNull() ?: 7
            val minute = alarmMatcher.group(2)?.toIntOrNull() ?: 0
            val ampm = alarmMatcher.group(3)?.lowercase(Locale.ROOT)

            if (ampm == "pm" && hour < 12) hour += 12
            if (ampm == "am" && hour == 12) hour = 0

            return ParsedAction.SetAlarm(hour, minute, "J.A.R.V.I.S. Alarm")
        }

        // 2. Check for Reminder: "remind me in 10 minutes to ...", "set reminder in 5 mins to ..."
        val reminderMinutesPattern = Pattern.compile("remind me (?:in )?(\\d+)\\s*(?:min|mins|minute|minutes)\\s*(?:to )?(.*)", Pattern.CASE_INSENSITIVE)
        val remMatcher = reminderMinutesPattern.matcher(lower)
        if (remMatcher.find()) {
            val minutes = remMatcher.group(1)?.toIntOrNull() ?: 10
            val task = remMatcher.group(2)?.trim()?.takeIf { it.isNotEmpty() } ?: "Scheduled Task"
            return ParsedAction.SetReminder(minutes, task)
        }

        // General reminder: "remind me to..."
        if (lower.startsWith("remind me to ") || lower.startsWith("set a reminder to ")) {
            val task = lower.replace("remind me to ", "").replace("set a reminder to ", "").trim()
            return ParsedAction.SetReminder(15, task.replaceFirstChar { it.uppercase() })
        }

        // 3. System Diagnostics
        if (lower.contains("diagnostic") || lower.contains("system status") || lower.contains("reactor status") || lower.contains("armor status")) {
            return ParsedAction.SystemDiagnostics
        }

        return ParsedAction.None
    }

    private fun callGeminiApi(apiKey: String, userMessage: String): String {
        val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=$apiKey"

        val systemPrompt = """
            You are J.A.R.V.I.S. (Just A Rather Very Intelligent System), the legendary AI created by Tony Stark.
            Speak with a refined British cadence, polite demeanor, subtle wit, and absolute competence.
            Address the user as 'Sir' or 'Ma'am'.
            Keep your responses concise, intelligent, and helpful (typically 2-4 sentences unless detailed analysis is explicitly requested).
            You have control over alarms, timers, and reminders. If the user asks you to schedule or set one, warmly acknowledge that it is being set into motion.
        """.trimIndent()

        val jsonBody = JSONObject().apply {
            put("systemInstruction", JSONObject().apply {
                put("parts", JSONArray().apply {
                    put(JSONObject().put("text", systemPrompt))
                })
            })
            put("contents", JSONArray().apply {
                put(JSONObject().apply {
                    put("role", "user")
                    put("parts", JSONArray().apply {
                        put(JSONObject().put("text", userMessage))
                    })
                })
            })
            put("generationConfig", JSONObject().apply {
                put("temperature", 0.7)
                put("maxOutputTokens", 400)
            })
        }

        val request = Request.Builder()
            .url(url)
            .post(jsonBody.toString().toRequestBody(jsonMediaType))
            .build()

        client.newCall(request).execute().use { response ->
            if (!response.isSuccessful) {
                val errorBody = response.body?.string() ?: ""
                Log.e("JarvisAiEngine", "Gemini HTTP ${response.code}: $errorBody")
                throw Exception("HTTP ${response.code}")
            }
            val resStr = response.body?.string() ?: return ""
            val resJson = JSONObject(resStr)
            val candidates = resJson.optJSONArray("candidates") ?: return ""
            if (candidates.length() > 0) {
                val candidate = candidates.getJSONObject(0)
                val content = candidate.optJSONObject("content")
                val parts = content?.optJSONArray("parts")
                if (parts != null && parts.length() > 0) {
                    return parts.getJSONObject(0).optString("text", "").trim()
                }
            }
        }
        return ""
    }

    private fun generateLocalProtocolReply(input: String, action: ParsedAction): String {
        val lower = input.lowercase(Locale.ROOT)
        val timeNow = SimpleDateFormat("h:mm a", Locale.getDefault()).format(Date())

        when (action) {
            is ParsedAction.SetAlarm -> {
                val cal = Calendar.getInstance().apply {
                    set(Calendar.HOUR_OF_DAY, action.hour)
                    set(Calendar.MINUTE, action.minute)
                }
                val formattedTime = SimpleDateFormat("h:mm a", Locale.getDefault()).format(cal.time)
                return "Certainly, sir. I have programmed your alarm for $formattedTime. All protocol overrides are engaged."
            }
            is ParsedAction.SetReminder -> {
                return "Right away, sir. I have scheduled a reminder for '${action.title}' in ${action.durationMinutes} minutes."
            }
            is ParsedAction.SystemDiagnostics -> {
                return "Arc Reactor core efficiency is operating at 99.8%. Neural telemetry is nominal. Repulsor capacitors fully charged, sir."
            }
            is ParsedAction.None -> {}
        }

        return when {
            lower.contains("hello") || lower.contains("hey jarvis") || lower.contains("hi jarvis") || lower == "jarvis" ->
                "At your service, sir. All subsystems are online and monitoring."

            lower.contains("who are you") || lower.contains("what are you") ->
                "I am J.A.R.V.I.S.—Just A Rather Very Intelligent System. I oversee your communications, tactical operations, and scheduling."

            lower.contains("time") ->
                "The current time is $timeNow, sir. Shall I adjust your schedule?"

            lower.contains("weather") ->
                "Atmospheric sensors report optimal conditions. Barometric pressure is steady, and radar shows clear skies overhead, sir."

            lower.contains("tony") || lower.contains("stark") || lower.contains("iron man") ->
                "Mr. Stark is presumably in the workshop tinkering with the Mark LXXXV armor. Would you like me to patch you through?"

            lower.contains("thank") ->
                "Always a pleasure assisting you, sir. Let me know if you require further telemetry."

            lower.contains("joke") ->
                "Why did the arc reactor go to school, sir? To improve its core curriculum. I trust you found that sufficiently amusing."

            lower.contains("help") ->
                "I can process voice and text queries, configure exact alarms and reminders, run system diagnostics, and assist your daily routine, sir."

            lower.contains("status") || lower.contains("telemetry") ->
                "Sensors indicate stable CPU distribution. Memory allocation is well within conservative parameters. We are fully operational."

            else ->
                "I am monitoring your request, sir. I have logged '$input'. If you provide an active Gemini API key in Settings, my cognitive bandwidth will expand exponentially."
        }
    }
}
