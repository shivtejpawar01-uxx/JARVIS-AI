package com.example.data

import android.content.Context
import android.content.SharedPreferences
import com.example.BuildConfig
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class JarvisPreferences(
    val customApiKey: String = "",
    val autoSpeak: Boolean = true,
    val ttsPitch: Float = 0.95f,
    val ttsRate: Float = 1.0f,
    val personality: String = "JARVIS_BUTLER",
    val lowRamMode: Boolean = false,
    val soundEffects: Boolean = true
)

class PreferencesManager(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("jarvis_prefs", Context.MODE_PRIVATE)

    private val _preferences = MutableStateFlow(loadPreferences())
    val preferences: StateFlow<JarvisPreferences> = _preferences.asStateFlow()

    private fun loadPreferences(): JarvisPreferences {
        return JarvisPreferences(
            customApiKey = prefs.getString("custom_api_key", "") ?: "",
            autoSpeak = prefs.getBoolean("auto_speak", true),
            ttsPitch = prefs.getFloat("tts_pitch", 0.95f),
            ttsRate = prefs.getFloat("tts_rate", 1.0f),
            personality = prefs.getString("personality", "JARVIS_BUTLER") ?: "JARVIS_BUTLER",
            lowRamMode = prefs.getBoolean("low_ram_mode", false),
            soundEffects = prefs.getBoolean("sound_effects", true)
        )
    }

    fun getEffectiveApiKey(): String {
        val custom = _preferences.value.customApiKey.trim()
        if (custom.isNotEmpty()) return custom

        // Try BuildConfig.GEMINI_API_KEY
        return try {
            val field = BuildConfig::class.java.getField("GEMINI_API_KEY")
            val key = field.get(null) as? String ?: ""
            if (key != "MY_GEMINI_API_KEY") key else ""
        } catch (_: Exception) {
            ""
        }
    }

    fun setCustomApiKey(key: String) {
        prefs.edit().putString("custom_api_key", key.trim()).apply()
        _preferences.value = _preferences.value.copy(customApiKey = key.trim())
    }

    fun setAutoSpeak(enabled: Boolean) {
        prefs.edit().putBoolean("auto_speak", enabled).apply()
        _preferences.value = _preferences.value.copy(autoSpeak = enabled)
    }

    fun setTtsPitch(pitch: Float) {
        prefs.edit().putFloat("tts_pitch", pitch).apply()
        _preferences.value = _preferences.value.copy(ttsPitch = pitch)
    }

    fun setTtsRate(rate: Float) {
        prefs.edit().putFloat("tts_rate", rate).apply()
        _preferences.value = _preferences.value.copy(ttsRate = rate)
    }

    fun setPersonality(personality: String) {
        prefs.edit().putString("personality", personality).apply()
        _preferences.value = _preferences.value.copy(personality = personality)
    }

    fun setLowRamMode(enabled: Boolean) {
        prefs.edit().putBoolean("low_ram_mode", enabled).apply()
        _preferences.value = _preferences.value.copy(lowRamMode = enabled)
    }

    fun setSoundEffects(enabled: Boolean) {
        prefs.edit().putBoolean("sound_effects", enabled).apply()
        _preferences.value = _preferences.value.copy(soundEffects = enabled)
    }
}
